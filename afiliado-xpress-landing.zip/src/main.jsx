import React from 'react';
import ReactDOM from 'react-dom/client';
import LandingAfiliadoXpress from './LandingAfiliadoXpress';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <LandingAfiliadoXpress />
  </React.StrictMode>
);